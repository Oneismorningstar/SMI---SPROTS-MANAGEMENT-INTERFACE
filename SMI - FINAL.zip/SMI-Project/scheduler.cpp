#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <algorithm>

using namespace std;

// Simple Structure to store a Team
struct Team {
    string name;
    string sport;
};

// Simple Structure to store one scheduled match
struct Match {
    string sport;
    string teamA;
    string teamB;
    string venue;
    int start;   // start hour on a 24-hour clock
};

// Each of these sports has its own ground.
// All other sports share the Statue Ground and the Stage Ground.
string getVenue(string sport, int matchNumber) {
    if (sport == "Cricket")      return "Cricket Ground";
    if (sport == "Football")     return "Football Ground";
    if (sport == "Basketball")   return "Basketball Ground";
    if (sport == "Table Tennis") return "Indoor Table Tennis Section";
    return (matchNumber % 2 == 0) ? "Statue Ground" : "Stage Ground";
}

string formatTime(int hour) {
    string ampm = (hour >= 12) ? "PM" : "AM";
    int hour12 = (hour > 12) ? hour - 12 : hour;
    return to_string(hour12) + ":00 " + ampm;
}

// Rules: 1) each sport uses its own ground
//        2) a venue is never used by two matches at the same time
//        3) a team gets a 2-hour gap before its next match
void generateFixtures(vector<Team> teams, vector<string> sports) {
    map<string, int> venueFree;   // time when each venue is free again
    map<string, int> teamFree;    // time when each team is free again
    vector<Match> matches;

    for (size_t s = 0; s < sports.size(); s++) {
        // Collect the teams of this sport
        vector<Team> sportTeams;
        for (size_t k = 0; k < teams.size(); k++) {
            if (teams[k].sport == sports[s]) sportTeams.push_back(teams[k]);
        }

        // Pair every team with every other team of the same sport
        for (size_t i = 0; i < sportTeams.size(); i++) {
            for (size_t j = i + 1; j < sportTeams.size(); j++) {
                string a = sportTeams[i].name;
                string b = sportTeams[j].name;
                string venue = getVenue(sports[s], matches.size());

                // Earliest time when the venue AND both teams are free (first match: 10 AM)
                int start = max({10, venueFree[venue], teamFree[a], teamFree[b]});

                // Block them for the next 2 hours
                venueFree[venue] = start + 2;
                teamFree[a] = start + 2;
                teamFree[b] = start + 2;

                matches.push_back({sports[s], a, b, venue, start});
            }
        }
    }

    // Show the earliest matches first
    stable_sort(matches.begin(), matches.end(),
                [](const Match& x, const Match& y) { return x.start < y.start; });

    cout << "\n--- SMI CONSTRAINT-BASED SCHEDULE ---\n";
    for (size_t i = 0; i < matches.size(); i++) {
        cout << "Match " << i + 1 << " (" << matches[i].sport << "): "
             << matches[i].teamA << " vs " << matches[i].teamB
             << " | Venue: " << matches[i].venue
             << " | Time: " << formatTime(matches[i].start) << "\n";
    }
}

int main() {
    vector<string> sports = {"Cricket", "Football", "Basketball", "Table Tennis",
                             "Badminton", "Volleyball", "Kabaddi"};

    // Sample teams including Last Time Legends
    vector<Team> teams = {
        {"Last Time Legends", "Cricket"},
        {"Super Strikers", "Cricket"},
        {"Titans FC", "Football"},
        {"Red Hawks", "Football"},
        {"Court Kings", "Basketball"},
        {"Hoop Dreams", "Basketball"},
        {"Paddle Pros", "Table Tennis"},
        {"Spin Masters", "Table Tennis"}
    };

    generateFixtures(teams, sports);
    return 0;
}
